A Game-Based Cybersecurity Testing and Analysis Tool

-Overview
This project is a Raspberry Pi–based cybersecurity toolkit presented through an interactive game-style interface built with Python and Pygame. Instead of using traditional terminal commands, users interact with cybersecurity tools through in-game locations called Shrines.
Each shrine activates a different cybersecurity module such as WiFi scanning, packet sniffing, or ESP8266 deauthentication tools.
The system is designed to demonstrate cybersecurity concepts in an interactive and educational way.

-Features
Game-Based Interface
Built using Python and Pygame
Interactive map with shrines
Player navigation using keyboard or virtual joystick
Tool activation through in-game interaction

-WiFi Scanner
Uses iwlist to scan nearby WiFi networks

-Displays:
SSID
Signal strength
Channel information
Visual radar-style interface inside the game
Packet Sniffer (Simulated)
Displays simulated packet traffic
Shows protocol, source IP, destination IP, and packet length
Demonstrates how packet capture works in network monitoring

-ESP8266 Deauther Control
Powers ESP8266 using Raspberry Pi GPIO
Connects to ESP8266 WiFi network
Opens Deauther Web Interface
Controlled from inside the game UI


-System Architecture
User (Mobile / Laptop)
        │
        │ VNC Viewer
        │
Raspberry Pi
│
├── Game Interface (Pygame)
│
├── WiFi Scanner (iwlist)
│
├── Packet Sniffer (Simulated)
│
└── ESP8266 Deauther
        │
        └── Web Interface

-Hardware Requirements
Raspberry Pi 4 / CM4 / Raspberry Pi 5
WiFi Adapter (USB Dongle recommended)
ESP8266 Deauther Module
4-inch HDMI Touch Display (optional)
Power Supply

-Software Requirements
Raspberry Pi OS
Python 3.9+
python library Pygame ,os, sys, math, time, random, subprocess, threading, webbrowser, re

-NetworkManager
nmcli
iwlist
VNC Server

-Install dependencies:
sudo apt update
sudo apt install python3-pygame wireless-tools network-manager

-Running the Project
Navigate to the project directory:
cd SpiralCityTool

-Run the game:
python3 main.py

-Controls
Keyboard
|Key	  |	Action       |
|---------|------------------|
|W A S D  | Move player	     |
|ENTER	  | Activate shrine  |
|ESC	  | Exit tool        |
|SPACE	  | Jump             |
|Virtual  | Controls         |


-On-screen joystick for movement
Buttons for Jump and Interact
Designed for mobile VNC control.


-The Raspberry Pi can be controlled remotely using:
VNC Viewer


-Recommended setup:
wlan0 → Internet / VNC
wlan1 → WiFi scanning / ESP8266 connection

-Educational Purpose
This project is created for educational and cybersecurity research purposes only.
It demonstrates network monitoring, wireless analysis, and security testing techniques.
Unauthorized use against networks without permission is strictly prohibited.
